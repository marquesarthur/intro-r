<img style="float: right;" src="figures/research_commons_logo.png">

# WORKSHOP: INTRODUCTION TO R FOR STATISTICAL ANALYSIS

* Arthur Marques (GAA)
* Minjeong Park
* Mohammad Zubair


***

# Learning Goals

<img src="figures/learning_objectives.png">

* Understand the basic commands of R and how to use RStudio environment

* Learn how to load, preprocess, and explore datasets

* Learn the basic commands for descriptive statistics

* Learn basic commands for inference statistics

***

## Workshop materials

### Access the UBC research commons R workshop

https://guides.library.ubc.ca/library_research_commons/rworkshop

<img src="figures/path_to_files.png">

***

### Download the files for this workshop

<img src="figures/save_to_desktop.png">

***

## Overview of quantitative research

<img src="figures/overview.png">

***

<img src="figures/comparison.png">

***

## R environment

### Open RStudio

<img src="figures/R_environment.png">

***

### Create a new R script 

#### File > New file > R Script

<img src="figures/R_Studio.png">

***

### Change your working directory

Set up a folder/path where data are located as a working directory 

<img src="figures/working_directory.png">

***

# Basic Commands

<img src="figures/learning_objectives.png">

***

### R packages

R package is a library of prewritten code designed for a particular task or a collection of tasks

<img src="figures/R_packages.png">

***

### Installing a new package (2 options)



#### Under Tools -> Packages tab -> Search for “psych” and “dplyr”

<img src="figures/install_packages.png">

***

#### Using code: install.packages( ) and library( ) functions

```
install.packages(c("ggplot2", "dplyr", "readr", "psych"))

library("ggplot2")
library("dplyr")
library("readr")
library("psych")
```

***


```R
install.packages(c("ggplot2", "dplyr", "readr", "psych"))

library("ggplot2")
library("dplyr")
library("readr")
```

    Installing packages into 'C:/Users/17783/Documents/R/win-library/3.6'
    (as 'lib' is unspecified)
    
    

    package 'ggplot2' successfully unpacked and MD5 sums checked
    package 'dplyr' successfully unpacked and MD5 sums checked
    package 'readr' successfully unpacked and MD5 sums checked
    package 'psych' successfully unpacked and MD5 sums checked
    
    The downloaded binary packages are in
    	C:\Users\17783\AppData\Local\Temp\Rtmpo3klau\downloaded_packages
    

    Warning message:
    "package 'ggplot2' was built under R version 3.6.3"
    Warning message:
    "package 'dplyr' was built under R version 3.6.3"
    
    Attaching package: 'dplyr'
    
    
    The following objects are masked from 'package:stats':
    
        filter, lag
    
    
    The following objects are masked from 'package:base':
    
        intersect, setdiff, setequal, union
    
    
    Warning message:
    "package 'readr' was built under R version 3.6.3"
    

#### Tips

**On the editor**

<kbd>CTRL</kbd>+<kbd>enter</kbd> runs the command in the current line (<kbd>cmd</kbd>+<kbd>enter</kbd> on MacOS)

<kbd>CTRL</kbd>+<kbd>w</kbd> closes current tab (<kbd>cmd</kbd>+<kbd>w</kbd> on MacOS)

After typing the first few lines of a command, <kbd>tab</kbd> auto-completes the command

**On the console**

<kbd>↑</kbd> shows the last command (useful to rerun the command of fix errors)

***


# Data Manipulation

<img src="figures/learning_objectives.png">

#### Our data

<img src="figures/global_warming.jpeg">

***

### Import data from excel



<img src="figures/data_import_from_excel.png">

***

### Preview data and give it a nice name


<img src="figures/data_import_preview.png">


***

### You can also load your data with the read_csv command


```R
mydata <- read.csv("GlobalLandTemperaturesByCountry.csv")
```


```R
head(mydata, 15)
```


<table>
<caption>A data.frame: 15 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td></tr>
	<tr><th scope=row>2</th><td>1743-12-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>3</th><td>1744-01-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>4</th><td>1744-02-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>5</th><td>1744-03-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>6</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td></tr>
	<tr><th scope=row>7</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td></tr>
	<tr><th scope=row>8</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td></tr>
	<tr><th scope=row>9</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td></tr>
	<tr><th scope=row>10</th><td>1744-08-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>11</th><td>1744-09-01</td><td>11.702</td><td>1.517</td><td>Ã…land</td></tr>
	<tr><th scope=row>12</th><td>1744-10-01</td><td> 5.477</td><td>1.862</td><td>Ã…land</td></tr>
	<tr><th scope=row>13</th><td>1744-11-01</td><td> 3.407</td><td>1.425</td><td>Ã…land</td></tr>
	<tr><th scope=row>14</th><td>1744-12-01</td><td>-2.181</td><td>1.641</td><td>Ã…land</td></tr>
	<tr><th scope=row>15</th><td>1745-01-01</td><td>-3.850</td><td>1.841</td><td>Ã…land</td></tr>
</tbody>
</table>



***

## Basic data commands 

### names( ): check variable names


```R
names(mydata)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'dt'</li><li>'AverageTemperature'</li><li>'AverageTemperatureUncertainty'</li><li>'Country'</li></ol>



***

### View first n lines of the table


```R
head(mydata, n = 10)
```


<table>
<caption>A data.frame: 10 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td></tr>
	<tr><th scope=row>2</th><td>1743-12-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>3</th><td>1744-01-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>4</th><td>1744-02-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>5</th><td>1744-03-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>6</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td></tr>
	<tr><th scope=row>7</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td></tr>
	<tr><th scope=row>8</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td></tr>
	<tr><th scope=row>9</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td></tr>
	<tr><th scope=row>10</th><td>1744-08-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
</tbody>
</table>



***

### table( ): check variable values and frequency

```
table(mydata$Country)
```


```R
head(table(mydata$Country), n=10)
```


    
            Ã…land    Afghanistan         Africa        Albania        Algeria 
              3239           2106           1965           3239           2721 
    American Samoa        Andorra         Angola       Anguilla     Antarctica 
              1761           3239           1878           2277            764 


***

## Basic data management commands

### is.factor( ): check if the variable is defined as categorical


```R
is.factor(mydata$Country)
```


TRUE


### as.factor( ): changes variable to categorical format


```R
mydata$Country <- as.factor(mydata$Country)
```


```R
is.factor(mydata$Country)
```


TRUE


### numeric( ): check if the variable is defined as numerical


```R
is.numeric(mydata$AverageTemperature)
```


TRUE


***

## Data management with "dplyr" package

### Removing empty cells/rows


```R
head(mydata, n = 10)
```


<table>
<caption>A data.frame: 10 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td></tr>
	<tr><th scope=row>2</th><td>1743-12-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>3</th><td>1744-01-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>4</th><td>1744-02-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>5</th><td>1744-03-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
	<tr><th scope=row>6</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td></tr>
	<tr><th scope=row>7</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td></tr>
	<tr><th scope=row>8</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td></tr>
	<tr><th scope=row>9</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td></tr>
	<tr><th scope=row>10</th><td>1744-08-01</td><td>    NA</td><td>   NA</td><td>Ã…land</td></tr>
</tbody>
</table>




```R
mydata <- na.omit(mydata)
```


```R
head(mydata, n = 10)
```


<table>
<caption>A data.frame: 10 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td></tr>
	<tr><th scope=row>6</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td></tr>
	<tr><th scope=row>7</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td></tr>
	<tr><th scope=row>8</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td></tr>
	<tr><th scope=row>9</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td></tr>
	<tr><th scope=row>11</th><td>1744-09-01</td><td>11.702</td><td>1.517</td><td>Ã…land</td></tr>
	<tr><th scope=row>12</th><td>1744-10-01</td><td> 5.477</td><td>1.862</td><td>Ã…land</td></tr>
	<tr><th scope=row>13</th><td>1744-11-01</td><td> 3.407</td><td>1.425</td><td>Ã…land</td></tr>
	<tr><th scope=row>14</th><td>1744-12-01</td><td>-2.181</td><td>1.641</td><td>Ã…land</td></tr>
	<tr><th scope=row>15</th><td>1745-01-01</td><td>-3.850</td><td>1.841</td><td>Ã…land</td></tr>
</tbody>
</table>




***

### select ( ): selects columns based on columns names


```R
head(select(mydata, dt, Country), n=5)
```


<table>
<caption>A data.frame: 5 × 2</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td>Ã…land</td></tr>
	<tr><th scope=row>6</th><td>1744-04-01</td><td>Ã…land</td></tr>
	<tr><th scope=row>7</th><td>1744-05-01</td><td>Ã…land</td></tr>
	<tr><th scope=row>8</th><td>1744-06-01</td><td>Ã…land</td></tr>
	<tr><th scope=row>9</th><td>1744-07-01</td><td>Ã…land</td></tr>
</tbody>
</table>



***

### filter ( ): selects cases based on conditions


```R
head(filter(mydata, Country=="Canada"))
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1768-09-01</td><td>  5.257</td><td>3.107</td><td>Canada</td></tr>
	<tr><th scope=row>2</th><td>1768-10-01</td><td> -3.393</td><td>2.981</td><td>Canada</td></tr>
	<tr><th scope=row>3</th><td>1768-11-01</td><td>-12.829</td><td>3.967</td><td>Canada</td></tr>
	<tr><th scope=row>4</th><td>1768-12-01</td><td>-20.582</td><td>4.622</td><td>Canada</td></tr>
	<tr><th scope=row>5</th><td>1769-01-01</td><td>-24.756</td><td>4.722</td><td>Canada</td></tr>
	<tr><th scope=row>6</th><td>1769-02-01</td><td>-22.915</td><td>2.871</td><td>Canada</td></tr>
</tbody>
</table>



### filter may accept more than one condition


```R
head(filter(mydata, Country=="Canada" | Country == "China"))
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1768-09-01</td><td>  5.257</td><td>3.107</td><td>Canada</td></tr>
	<tr><th scope=row>2</th><td>1768-10-01</td><td> -3.393</td><td>2.981</td><td>Canada</td></tr>
	<tr><th scope=row>3</th><td>1768-11-01</td><td>-12.829</td><td>3.967</td><td>Canada</td></tr>
	<tr><th scope=row>4</th><td>1768-12-01</td><td>-20.582</td><td>4.622</td><td>Canada</td></tr>
	<tr><th scope=row>5</th><td>1769-01-01</td><td>-24.756</td><td>4.722</td><td>Canada</td></tr>
	<tr><th scope=row>6</th><td>1769-02-01</td><td>-22.915</td><td>2.871</td><td>Canada</td></tr>
</tbody>
</table>




```R
head(filter(mydata, Country=="Canada" & AverageTemperature > 12))
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1769-07-01</td><td>13.953</td><td>2.945</td><td>Canada</td></tr>
	<tr><th scope=row>2</th><td>1775-07-01</td><td>12.797</td><td>2.343</td><td>Canada</td></tr>
	<tr><th scope=row>3</th><td>1776-08-01</td><td>12.487</td><td>3.137</td><td>Canada</td></tr>
	<tr><th scope=row>4</th><td>1780-07-01</td><td>14.635</td><td>2.816</td><td>Canada</td></tr>
	<tr><th scope=row>5</th><td>1782-07-01</td><td>12.307</td><td>4.053</td><td>Canada</td></tr>
	<tr><th scope=row>6</th><td>1796-07-01</td><td>12.637</td><td>3.010</td><td>Canada</td></tr>
</tbody>
</table>



***

### mutate( ): adds new variables

#### Adding column representing the year


```R
mydata <- mutate(mydata, year = as.numeric(format(as.Date(dt), "%Y")))
```


```R
head(mydata)
```


<table>
<caption>A data.frame: 6 × 5</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th><th scope=col>year</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td><td>1743</td></tr>
	<tr><th scope=row>2</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td><td>1744</td></tr>
	<tr><th scope=row>3</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td><td>1744</td></tr>
	<tr><th scope=row>4</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td><td>1744</td></tr>
	<tr><th scope=row>5</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td><td>1744</td></tr>
	<tr><th scope=row>6</th><td>1744-09-01</td><td>11.702</td><td>1.517</td><td>Ã…land</td><td>1744</td></tr>
</tbody>
</table>




```R
is.numeric(mydata$year)
```


TRUE


**Whait? What?**

Command breakdown:

The commands below should be run on RStudio:

```
format(as.Date(mydata$dt), "%Y")
as.numeric(format(as.Date(mydata$dt), "%Y"))
mutate(mydata, year = as.numeric(format(as.Date(dt), "%Y")))
mydata <- mutate(mydata, year = as.numeric(format(as.Date(dt), "%Y")))
```

***

#### Adding column representing the industrial era


```R
mydata <- mutate(mydata, era=if_else(
    year <= 1969, "gas & oil", "electronic",
))

head(mydata, n=5)
```


<table>
<caption>A data.frame: 5 × 6</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th><th scope=col>year</th><th scope=col>era</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td><td>1743</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>2</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>3</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>4</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>5</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
</tbody>
</table>




```R
tail(mydata, n=5)
```


<table>
<caption>A data.frame: 5 × 6</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th><th scope=col>year</th><th scope=col>era</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>544807</th><td>2013-04-01</td><td>21.142</td><td>0.495</td><td>Zimbabwe</td><td>2013</td><td>electronic</td></tr>
	<tr><th scope=row>544808</th><td>2013-05-01</td><td>19.059</td><td>1.022</td><td>Zimbabwe</td><td>2013</td><td>electronic</td></tr>
	<tr><th scope=row>544809</th><td>2013-06-01</td><td>17.613</td><td>0.473</td><td>Zimbabwe</td><td>2013</td><td>electronic</td></tr>
	<tr><th scope=row>544810</th><td>2013-07-01</td><td>17.000</td><td>0.453</td><td>Zimbabwe</td><td>2013</td><td>electronic</td></tr>
	<tr><th scope=row>544811</th><td>2013-08-01</td><td>19.759</td><td>0.717</td><td>Zimbabwe</td><td>2013</td><td>electronic</td></tr>
</tbody>
</table>



***

# Descriptive Statistics

<img src="figures/learning_objectives.png">

### Descriptive stat with basic summary function


```R
summary(mydata)
```


              dt         AverageTemperature AverageTemperatureUncertainty
     1948-02-01:   242   Min.   :-37.66     Min.   : 0.052               
     1948-03-01:   242   1st Qu.: 10.03     1st Qu.: 0.323               
     1948-04-01:   242   Median : 20.90     Median : 0.571               
     1948-05-01:   242   Mean   : 17.19     Mean   : 1.019               
     1948-06-01:   242   3rd Qu.: 25.81     3rd Qu.: 1.207               
     1948-07-01:   242   Max.   : 38.84     Max.   :15.003               
     (Other)   :543359                                                   
        Country            year          era           
     Ã…land :  3166   Min.   :1743   Length:544811     
     Albania:  3166   1st Qu.:1869   Class :character  
     Andorra:  3166   Median :1919   Mode  :character  
     Austria:  3166   Mean   :1913                     
     Belarus:  3166   3rd Qu.:1966                     
     Belgium:  3166   Max.   :2013                     
     (Other):525815                                    


***

### Descriptive statistics with visualization 

#### Create histogram for “year” 


```R
hist(mydata$year)
```


![png](output_60_0.png)


#### Create a histogram using gpplot 2

* ggplot(mydata, aes(x=year)) creates a plot using `mydata` aes defines the `x`, `y` and many other axis
* geom_histogram defines de plot as a histogram, `binwidth` defines de width of the bars
* scale_y_continuous(trans='log2') transforms the scale of the graph to `log2` delete `+ scale_y_continuous(trans='log2')` and check what happens
* theme_light() changes the theme. There are various themes like black and white or color blind. 
* labs(x="years", y="Frequency", face="bold") changes the `x` and `y` labels in the plot


```R
g <- ggplot(mydata, aes(x=year)) + geom_histogram(binwidth=.9) + scale_y_continuous(trans='log2')
g <- g + theme_light() + labs(x="years", y="Frequency", face="bold")
g
```

    Warning message:
    "Transformation introduced infinite values in continuous y-axis"
    Warning message:
    "Removed 34 rows containing missing values (geom_bar)."
    


![png](output_62_1.png)


***

#### Create histogram for “Countries” 


```R
barplot(table(mydata$era))
```


![png](output_64_0.png)


***

### More visualization functions with “ggplot2”

Try to run this command:

```
ggplot(data=mydata, aes(x=year, y=AverageTemperature)) + geom_line()
```


```R
ggplot(data=mydata, aes(x=year, y=AverageTemperature)) + geom_line()
```


![png](output_67_0.png)


<img src="figures/staring.jpg">

### Can we do better? 

What if we can create smaller data with the year and the average temperature of that year?


```R
grouped_data <- mydata  %>%
    group_by(year) %>%
    summarise(avg_temp = mean(AverageTemperature))
```


```R
head(grouped_data)
```


<table>
<caption>A tibble: 6 × 2</caption>
<thead>
	<tr><th scope=col>year</th><th scope=col>avg_temp</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>1743</td><td>5.184140</td></tr>
	<tr><td>1744</td><td>9.837898</td></tr>
	<tr><td>1745</td><td>1.387125</td></tr>
	<tr><td>1750</td><td>9.129353</td></tr>
	<tr><td>1751</td><td>9.167388</td></tr>
	<tr><td>1752</td><td>4.413387</td></tr>
</tbody>
</table>




```R
ggplot(data=grouped_data, aes(x=year, y=avg_temp)) +
  geom_line()
```


![png](output_72_0.png)


# Exercise

## If we are on track, try to:


### 1. load carbon dioxide data

### 2. remove NA

### 3. Change column "CarbonDioxide" to numeric

### 4. Change column "year" to numeric

### view the data using the head( )  and tail( ) commands


<br><br><br><br>


## Don't spoil the fun. The stick figure is watching you


<br><br><br><br>


<img src="figures/watch.png" width="30%">

### Answer:


```R
carbon <- read.csv("CarbonDioxideEmission.csv")
```


```R
carbon <- na.omit(carbon)

carbon$CarbonDioxide <- as.numeric(carbon$CarbonDioxide)
carbon$year <- as.numeric(carbon$year)

head(carbon)
tail(carbon)
```


<table>
<caption>A data.frame: 6 × 7</caption>
<thead>
	<tr><th></th><th scope=col>year</th><th scope=col>Month</th><th scope=col>DecimalDate</th><th scope=col>CarbonDioxide</th><th scope=col>SeasonallyAdjustedCO2</th><th scope=col>CarbonDioxideFit</th><th scope=col>SeasonallyAdjustedCO2Fit</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>3</th><td>1958</td><td>3</td><td>1958.203</td><td>315.69</td><td>314.42</td><td>316.18</td><td>314.89</td></tr>
	<tr><th scope=row>4</th><td>1958</td><td>4</td><td>1958.288</td><td>317.45</td><td>315.15</td><td>317.30</td><td>314.98</td></tr>
	<tr><th scope=row>5</th><td>1958</td><td>5</td><td>1958.370</td><td>317.50</td><td>314.73</td><td>317.83</td><td>315.06</td></tr>
	<tr><th scope=row>7</th><td>1958</td><td>7</td><td>1958.537</td><td>315.86</td><td>315.17</td><td>315.87</td><td>315.21</td></tr>
	<tr><th scope=row>8</th><td>1958</td><td>8</td><td>1958.622</td><td>314.93</td><td>316.17</td><td>314.01</td><td>315.29</td></tr>
	<tr><th scope=row>9</th><td>1958</td><td>9</td><td>1958.707</td><td>313.21</td><td>316.06</td><td>312.48</td><td>315.35</td></tr>
</tbody>
</table>




<table>
<caption>A data.frame: 6 × 7</caption>
<thead>
	<tr><th></th><th scope=col>year</th><th scope=col>Month</th><th scope=col>DecimalDate</th><th scope=col>CarbonDioxide</th><th scope=col>SeasonallyAdjustedCO2</th><th scope=col>CarbonDioxideFit</th><th scope=col>SeasonallyAdjustedCO2Fit</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>704</th><td>2016</td><td> 8</td><td>2016.623</td><td>402.24</td><td>403.78</td><td>403.02</td><td>404.60</td></tr>
	<tr><th scope=row>705</th><td>2016</td><td> 9</td><td>2016.708</td><td>401.01</td><td>404.52</td><td>401.33</td><td>404.85</td></tr>
	<tr><th scope=row>706</th><td>2016</td><td>10</td><td>2016.790</td><td>401.50</td><td>405.12</td><td>401.48</td><td>405.09</td></tr>
	<tr><th scope=row>707</th><td>2016</td><td>11</td><td>2016.874</td><td>403.64</td><td>405.92</td><td>403.08</td><td>405.34</td></tr>
	<tr><th scope=row>708</th><td>2016</td><td>12</td><td>2016.956</td><td>404.55</td><td>405.49</td><td>404.66</td><td>405.58</td></tr>
	<tr><th scope=row>709</th><td>2017</td><td> 1</td><td>2017.041</td><td>406.07</td><td>406.04</td><td>405.87</td><td>405.83</td></tr>
</tbody>
</table>



# Inference Statistics

<img src="figures/learning_objectives.png">

## Some housekeeping and background

### Copy & run the code below 


```R
carbon <- group_by(carbon, year) %>%
    summarise(AverageCarbonEmission = mean(CarbonDioxide))

newdata <- group_by(mydata, year, era) %>%
    summarise(AverageTemperature = mean(AverageTemperature))

carbon <- merge(newdata, carbon[, c("year", "AverageCarbonEmission")], by="year")
head(carbon)
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>year</th><th scope=col>era</th><th scope=col>AverageTemperature</th><th scope=col>AverageCarbonEmission</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1958</td><td>gas &amp; oil</td><td>18.94217</td><td>315.3300</td></tr>
	<tr><th scope=row>2</th><td>1959</td><td>gas &amp; oil</td><td>18.82521</td><td>315.9817</td></tr>
	<tr><th scope=row>3</th><td>1960</td><td>gas &amp; oil</td><td>18.88701</td><td>316.9083</td></tr>
	<tr><th scope=row>4</th><td>1961</td><td>gas &amp; oil</td><td>18.92357</td><td>317.6450</td></tr>
	<tr><th scope=row>5</th><td>1962</td><td>gas &amp; oil</td><td>18.69385</td><td>318.4533</td></tr>
	<tr><th scope=row>6</th><td>1963</td><td>gas &amp; oil</td><td>18.67525</td><td>318.9925</td></tr>
</tbody>
</table>



### You may want to review this code at home, but for now let's just consider that it merges two datasets

A detailed explanation for later reference explained line-by-line:

1. the `carbon` data will be updated with the result of the right-hand operation. The right-hand operation groups the dataset by year


2. after grouping, we apply the `summarise` to create a column named `carbon` the value of the column is the `mean` of the `CarbonDioxide` emission


3. we do a similar grouping operation creating a `newdata` data. 


4. this time, we are interested in the mean of the `AverageTemperature`


5. we now have two variables, one with the `year` and `AverageCarbonEmission` and another with year and `AverageTemperature`. Let's `merge` these two tables in a final `carbon` table. Our merging criteria is the `year` and we will copy two columns from the initial carbon table: `c("year", "AverageCarbonEmission")`

<br>

### Hypothesis testing

From [Wikipedia](https://en.wikipedia.org/wiki/Statistical_significance):

#### To determine whether a result is statistically significant, a researcher calculates a p-value, which is the probability of observing an effect of the same magnitude or more extreme given that the null hypothesis is true.

#### The null hypothesis is rejected if the p-value is less than a predetermined level, α.

#### α is called the significance level, and is the probability of rejecting the null hypothesis given that it is true (a type I error). 

#### α is usually set at or below 5%.

<img src="figures/normal_curve.png">

## Our null hypotheses

### There is no difference in the Average temperature in the `gas & oil` era and the `electronic` era


```R
head(mydata)
```


<table>
<caption>A data.frame: 6 × 6</caption>
<thead>
	<tr><th></th><th scope=col>dt</th><th scope=col>AverageTemperature</th><th scope=col>AverageTemperatureUncertainty</th><th scope=col>Country</th><th scope=col>year</th><th scope=col>era</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1743-11-01</td><td> 4.384</td><td>2.294</td><td>Ã…land</td><td>1743</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>2</th><td>1744-04-01</td><td> 1.530</td><td>4.680</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>3</th><td>1744-05-01</td><td> 6.702</td><td>1.789</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>4</th><td>1744-06-01</td><td>11.609</td><td>1.577</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>5</th><td>1744-07-01</td><td>15.342</td><td>1.410</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
	<tr><th scope=row>6</th><td>1744-09-01</td><td>11.702</td><td>1.517</td><td>Ã…land</td><td>1744</td><td>gas &amp; oil</td></tr>
</tbody>
</table>



#### Independent T-test compares means between two groups

It is often used to see whether there is a group difference in continuous data **between two groups** 

*Model assumptions*

    (1) Independence

    (2) Normality

    (3) Equal variance


```R
t.test(AverageTemperature ~ era, data=carbon, var.eq=TRUE)
```


    
    	Two Sample t-test
    
    data:  AverageTemperature by era
    t = 3.7437, df = 54, p-value = 0.0004415
    alternative hypothesis: true difference in means is not equal to 0
    95 percent confidence interval:
     0.1806106 0.5970976
    sample estimates:
    mean in group electronic  mean in group gas & oil 
                    19.13249                 18.74364 
    


Interpreting the results:

* `t` value guides our analysis. Read more at this [link](https://blog.minitab.com/blog/adventures-in-statistics-2/understanding-t-tests-t-values-and-t-distributions)
* `df = 54` degrees of freedom 
* `p-value < 0.0004415` pretty low, so that means that we can reject the null hypothesis

<br>

* Which one seems higher?
    * mean in group `gas & oil` = `18.74364`
    * mean in group `eletronics` = `19.13249`


### Is there any association between the `AverageTemperature` and the `AverageCarbonEmission`  ?

#### Pearson’s correlation is used to examine associations between variables (represented by continuous data) by looking at the direction and strength of the associations


```R
cor.test(carbon$AverageTemperature, carbon$AverageCarbonEmission, method="pearson")
```


    
    	Pearson's product-moment correlation
    
    data:  carbon$AverageTemperature and carbon$AverageCarbonEmission
    t = 14.919, df = 54, p-value < 2.2e-16
    alternative hypothesis: true correlation is not equal to 0
    95 percent confidence interval:
     0.8299122 0.9386169
    sample estimates:
          cor 
    0.8970832 
    


Interpreting the results:

* `p-value < 2.2e-16` pretty low, so that means that there is statistically significant correlation between `temperature` and `carbon emission`

<br>

* How strong is the correlation  `cor` = `0.8970832` 

    Interpretation varies by research field so results should be interpreted with caution
    
    `cor` varies from `-1` to `1` positive values indicate that an increase in the `x` variable increases the `y` variable. In this case, a value closer to `1` means a strong positive correlation


***

### Did we do the correct analysis?

### What if the data is not normally distributed?

#### Let us test for normality using the Shapiro-Wilk test:

**Null hypothesis**: The data is normally distributed. If p > 0.05, normality can be assumed.


```R
shapiro.test(carbon$AverageTemperature)
```


    
    	Shapiro-Wilk normality test
    
    data:  carbon$AverageTemperature
    W = 0.94052, p-value = 0.008176
    


* `p-value < 0.05` So we reject the null hypothesis and our data is skewed 

#### We can also check data visually 


```R
ggplot(carbon, aes(x=AverageTemperature)) + 
  geom_density()
```


![png](output_95_0.png)


***

### So what tests should we run?


Parametric test | R | Non-parametric test | R
--- | --- | --- | ---
Independent t-test | `t.test(y~x)` |  Mann-Whitney test | `wilcox.test(y~x)`
Paired t-test | `t.test(y1, y2, paired=TRUE)` | Wilcoxon signed rank test | `wilcox.test(y1,y2,paired=TRUE)`
One-way ANOVA | `aov(y ~ x, data = my_data)` |  Kruskal-Wallis test | `kruskal.test(y~x)`
Pearson's correlation | `cor.test(x, y, method=c("pearson")` | Spearman's correlation | `cor.test(x, y, method=c("spearman")`

These are only some examples

***

# Exercise

## If we are on track, try to:


### 1. Run the proper non-parametric tests for our data/analysis




<br><br><br><br>


## Don't spoil the fun. The stick figure is watching you


<br><br><br><br>


<img src="figures/watch.png" width="30%">

***

### Answer:



### Mann-Whitney test


```R
wilcox.test(AverageTemperature ~ era, data=carbon)
```


    
    	Wilcoxon rank sum test
    
    data:  AverageTemperature by era
    W = 437, p-value = 0.0002986
    alternative hypothesis: true location shift is not equal to 0
    


***

### Spearman Correlation


```R
cor.test(carbon$AverageTemperature, carbon$AverageCarbonEmission, method="spearman")
```


    
    	Spearman's rank correlation rho
    
    data:  carbon$AverageTemperature and carbon$AverageCarbonEmission
    S = 4452, p-value < 2.2e-16
    alternative hypothesis: true rho is not equal to 0
    sample estimates:
          rho 
    0.8478469 
    


***

### Conclusions from our analysis

<img src="figures/this_is_fine.png">

***

# Research Commons: An interdisciplinary research-driven learning environment


### * Literature review
### * Systematic Review Search  Methodology
### * Citation Management
### * Thesis Formatting 


### * Nvivo Software Support



### * SPSS Software Support

<img style="float: right;" src="figures/research_commons_logo.png">


### * R Group



### * Multi-Disciplinary Graduate Student Writing Group

***

<img style="position: relative;" src="figures/background.png">

<img style="position: absolute; top: 50px; left: 200px; background: rgba(255,255,255, 0.5);" src="figures/thanks.png">



<center> <h1>Feedback</h1><h2>http://bit.ly/RCfeedbackwinter2018</h2> </center>

